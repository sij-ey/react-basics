import styles from './TodoItem.module.css';

function TodoItem({ todo, onToggle, onDelete }) {
  return (
    <li className={styles.item}>
      <span
        className={`${styles.text} ${todo.completed ? styles.completed : ''}`}
        onClick={onToggle}
      >
        {todo.text}
      </span>
      <button className={styles.deleteButton} onClick={onDelete}>❌</button>
    </li>
  );
}

export default TodoItem;
