import TodoItem from './TodoItem';
import styles from './TodoList.module.css';

function TodoList({ todos, toggleTodo, deleteTodo }) {
  return (
    <ul className={styles.list}>
      {todos.map(todo => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggle={() => toggleTodo(todo.id)}
          onDelete={() => deleteTodo(todo.id)}
        />
      ))}
    </ul>
  );
}

export default TodoList;
