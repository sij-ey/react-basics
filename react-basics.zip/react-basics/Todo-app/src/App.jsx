import { useEffect, useState } from 'react';
import TodoList from './components/TodoList';
import styles from './App.module.css';

const API_URL = 'http://localhost:4000/todos'; // Adjust as needed

function App() {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetch(API_URL)
      .then(res => res.json())
      .then(setTodos);
  }, []);

  const addTodo = () => {
    if (input.trim()) {
      fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: input }),
      })
        .then(res => res.json())
        .then(newTodo => setTodos([...todos, newTodo]));
      setInput('');
    }
  };

  const toggleTodo = (id) => {
    const todo = todos.find(t => t.id === id);
    if (!todo) return;
    fetch(`${API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: !todo.completed }),
    })
      .then(res => res.json())
      .then(updated => {
        setTodos(todos.map(t => (t.id === updated.id ? updated : t)));
      });
  };

  const deleteTodo = (id) => {
    fetch(`${API_URL}/${id}`, { method: 'DELETE' }).then(() => {
      setTodos(todos.filter(t => t.id !== id));
    });
  };

  const filteredTodos = todos.filter(todo => {
    if (filter === 'completed') return todo.completed;
    if (filter === 'pending') return !todo.completed;
    return true;
  });

  return (
    <div className={styles.container}>
      <h1>📝 To-Do List</h1>
      <div className={styles.inputGroup}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Add a new task"
        />
        <button onClick={addTodo}>Add</button>
      </div>

      <div className={styles.filters}>
        {['all', 'completed', 'pending'].map((type) => (
          <button
            key={type}
            onClick={() => setFilter(type)}
            className={`${styles.filterButton} ${filter === type ? styles.active : ''}`}
          >
            {type[0].toUpperCase() + type.slice(1)}
          </button>
        ))}
      </div>

      <TodoList todos={filteredTodos} toggleTodo={toggleTodo} deleteTodo={deleteTodo} />
    </div>
  );
}

export default App;
