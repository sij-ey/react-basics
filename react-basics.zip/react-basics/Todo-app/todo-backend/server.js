const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

const app = express();
const PORT = 4000;
const DATA_FILE = './todos.json';

app.use(cors());
app.use(bodyParser.json());

const readTodos = () => {
  if (!fs.existsSync(DATA_FILE)) return [];
  return JSON.parse(fs.readFileSync(DATA_FILE));
};

const writeTodos = (todos) => {
  fs.writeFileSync(DATA_FILE, JSON.stringify(todos, null, 2));
};

// GET /todos
app.get('/todos', (req, res) => {
  res.json(readTodos());
});

// POST /todos
app.post('/todos', (req, res) => {
  const todos = readTodos();
  const newTodo = {
    id: uuidv4(),
    text: req.body.text,
    completed: false,
  };
  todos.push(newTodo);
  writeTodos(todos);
  res.status(201).json(newTodo);
});

// PUT /todos/:id
app.put('/todos/:id', (req, res) => {
  let todos = readTodos();
  const index = todos.findIndex((todo) => todo.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Todo not found' });

  todos[index] = { ...todos[index], ...req.body };
  writeTodos(todos);
  res.json(todos[index]);
});

// DELETE /todos/:id
app.delete('/todos/:id', (req, res) => {
  let todos = readTodos();
  const filtered = todos.filter((todo) => todo.id !== req.params.id);
  if (todos.length === filtered.length)
    return res.status(404).json({ error: 'Todo not found' });

  writeTodos(filtered);
  res.status(204).send();
});

app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
